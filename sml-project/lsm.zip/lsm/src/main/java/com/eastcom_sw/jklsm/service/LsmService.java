package com.eastcom_sw.jklsm.service;

import org.hw.sml.manager.service.RcptBaseService;
import org.springframework.stereotype.Service;

@Service
public class LsmService extends RcptBaseService{

}
